package stepdefinations;



import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.AutoZone.qa.Baseclass;
import com.AutoZone.qa.Dropdowns;
import com.AutoZone.qa.NDropDown;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Demotest extends Baseclass
{
	public Demotest() throws Exception
	{
		super();
	}
	@Given("^launch the application and search product$")
	public void launch_the_application_and_search_product() throws Throwable 
	{
		Baseclass.launchApp();
		String title=driver.getTitle();
		if(title.equalsIgnoreCase(pro.getProperty("Title")))
		{
			System.out.println(title);
		}
	    
	}

	@When("^add vehicle information and click on product$")
	public void add_vehicle_information_and_click_on_product() throws Throwable 
	{
		WebDriverWait wait= new WebDriverWait(driver, 10);
		driver.findElement(By.xpath(pro.getProperty("selectStore"))).click();
		driver.findElement(By.xpath(pro.getProperty("changeStore"))).click();
		driver.findElement(By.xpath(pro.getProperty("location"))).sendKeys(pro.getProperty("locationInput"));
		driver.findElement(By.xpath(pro.getProperty("submitSearch"))).click();
		List<WebElement> stores=driver.findElements(By.xpath(pro.getProperty("setStore")));
		stores.get(0).click();
		driver.findElement(By.xpath(pro.getProperty("year"))).sendKeys(pro.getProperty("yearInput"));
		WebElement year=driver.findElement(By.xpath(pro.getProperty("yearSelect")));
		NDropDown.handleNewDrop(year);
		driver.findElement(By.xpath(pro.getProperty("make"))).sendKeys(pro.getProperty("makeInput"));
		WebElement make=driver.findElement(By.xpath(pro.getProperty("makeSelect")));
		NDropDown.handleNewDrop(make);
		driver.findElement(By.xpath(pro.getProperty("model"))).sendKeys(pro.getProperty("modelInput"));
		WebElement model=driver.findElement(By.xpath(pro.getProperty("modelSelect")));
		NDropDown.handleNewDrop(model);
		Actions action = new Actions(driver);
		action.sendKeys(Keys.PAGE_UP).sendKeys(Keys.PAGE_UP).sendKeys(Keys.PAGE_UP).build().perform();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(pro.getProperty("seachbox"))));
		WebElement box= driver.findElement(By.xpath(pro.getProperty("seachbox")));
		box.sendKeys(pro.getProperty("itemName"));
		driver.findElement(By.xpath(pro.getProperty("searchbutton"))).click();
		driver.findElement(By.xpath(pro.getProperty("marine"))).click();
		String item=driver.findElement(By.xpath(pro.getProperty("verifyItem"))).getText();
		if(item.equalsIgnoreCase(pro.getProperty("itemName")))
		{
			System.out.println(item);
		}
		else 
		{
			System.out.println("Selected Item is not correct");
		}
		
				  
	}

	@When("^add item into cart$")
	public void add_item_into_cart() throws Throwable 
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,500)", "");
		Thread.sleep(500);
		WebDriverWait wait= new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(pro.getProperty("cart"))));
		driver.findElement(By.xpath(pro.getProperty("cart"))).click();
		driver.findElement(By.xpath(pro.getProperty("viewcart"))).click();
		driver.findElement(By.xpath(pro.getProperty("checkOut"))).click();
		Thread.sleep(1000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(pro.getProperty("Guest"))));
		driver.findElement(By.xpath(pro.getProperty("Guest"))).click();
		driver.findElement(By.xpath(pro.getProperty("continue"))).click();
		
	    
	}
	
	@When("^proceed for payment using details$")
	public void proceed_for_payment_using_details() throws Throwable  
	{
		driver.findElement(By.xpath(pro.getProperty("card"))).sendKeys(pro.getProperty("cardInput"));
		driver.findElement(By.xpath(pro.getProperty("expiry"))).sendKeys(pro.getProperty("expiryInput"));
		driver.findElement(By.xpath(pro.getProperty("securityCode"))).sendKeys(pro.getProperty("securityCodeInput"));
//		driver.findElement(By.xpath(pro.getProperty("card"))).sendKeys(card_Number);
		driver.findElement(By.xpath(pro.getProperty("continue"))).click();
		driver.findElement(By.xpath(pro.getProperty("firstName"))).sendKeys(pro.getProperty("firstNameInput"));
		driver.findElement(By.xpath(pro.getProperty("lastName"))).sendKeys(pro.getProperty("lastNameInput"));
		driver.findElement(By.xpath(pro.getProperty("phoneNumber"))).sendKeys(pro.getProperty("phoneInput"));
		driver.findElement(By.xpath(pro.getProperty("email"))).sendKeys(pro.getProperty("emailInput"));
		driver.findElement(By.xpath(pro.getProperty("address1"))).sendKeys(pro.getProperty("address1Input"));
		driver.findElement(By.xpath(pro.getProperty("address2"))).sendKeys(pro.getProperty("address2Input"));
		driver.findElement(By.xpath(pro.getProperty("city"))).sendKeys(pro.getProperty("cityInput"));
		WebElement state=driver.findElement(By.xpath(pro.getProperty("state")));
		Dropdowns.handlebyText(state, "ALASKA");
		driver.findElement(By.xpath(pro.getProperty("zipCode"))).sendKeys(pro.getProperty("locationInput"));
		driver.findElement(By.xpath(pro.getProperty("continue"))).click();
		driver.findElement(By.xpath(pro.getProperty("completePurchase"))).click();
		
		
		
	}
	    

	@Then("^payment successfull or Reject$")
	public void payment_successfull_or_Reject() throws Throwable {
	    String error= driver.findElement(By.xpath(pro.getProperty("faildPayment"))).getText();
	    if(error.equalsIgnoreCase(pro.getProperty("failedText")))
		{
			System.out.println(error);
		}
	    else
	    {
	    	System.out.println("Payment successfully done");
	    }
	    
		driver.close();
	}

}
