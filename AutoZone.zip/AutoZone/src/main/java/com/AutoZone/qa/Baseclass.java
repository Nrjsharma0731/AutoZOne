package com.AutoZone.qa;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Baseclass 
{
	public static Properties pro;
	public static WebDriver driver;
	
	public Baseclass() throws Exception
	{
		pro=new Properties();
		FileInputStream file= new FileInputStream("src/main/java/Resources/locators.properties");
		
		pro.load(file);
	}
public static void launchApp() 
{
	String browsername=pro.getProperty("browser");
	
	if(browsername.equals("chrome"))
	{
		System.setProperty("webdriver.chrome.driver", "src/main/java/drivers/chromedriver.exe");
		driver= new ChromeDriver();
	}
	else if(browsername.equals("firefox"))
	{
		System.setProperty("webdriver.gecko.driver", "src/main/java/drivers/geckodriver.exe");
		driver = new FirefoxDriver();
			
	}
	
	driver.manage().window().maximize();
	driver.get(pro.getProperty("URL"));
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
	
	
}
}