package com.AutoZone.qa;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class NDropDown extends Baseclass
{
	public NDropDown() throws Exception
	{
		super();
	}
	
	public static void handleNewDrop(WebElement ele)
	{
		Actions action = new Actions(driver);

		action.moveToElement(ele).click().build().perform();
			
			 
	}
	

}
