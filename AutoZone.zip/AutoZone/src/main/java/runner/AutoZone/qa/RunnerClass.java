package runner.AutoZone.qa;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features=("src/main/java/Features"),
		glue= ("stepdefinations"),
		dryRun = false,
		plugin = {"pretty", "json:target/cucumber-reports/cucumber.json",
				"html:target/cucumber-report/cucumber.html"}
		)

public class RunnerClass {

}
